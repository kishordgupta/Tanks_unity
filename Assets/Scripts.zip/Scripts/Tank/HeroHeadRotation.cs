﻿using UnityEngine;
using System.Collections;

public class HeroHeadRotation : MonoBehaviour
{
    public Transform rotationCenter;
    //public Vector3 targetPosition;
    public float rotationSpeed = 20f;//degrees
    private float targetAngle;
    private Movement movementScript;
    private Quaternion targetRotation;

    void Awake()
    {
        this.movementScript = this.GetComponentInParent<Movement>();
        this.targetRotation = Quaternion.Euler(0, 0, this.targetAngle);
    }
    
    // Use this for initialization
    void Start()
    {
        
    }
    
    // Update is called once per frame
    void Update()
    {
//        if (Application.loadedLevel != 0)
        {
       
            if (this.transform.rotation.eulerAngles != this.transform.localRotation.eulerAngles)
            {
//                Debug.LogWarning(string.Format("Tank head's rotation: {0} vs {1}", this.transform.rotation.eulerAngles,
//                                           this.transform.localRotation.eulerAngles));
            }
        
            if (this.movementScript == null)
            {
                return;
            }
//        if (!PlayerMovement.joyStickTouch)
            {
//            if()
                var y = this.movementScript.fireTarget.y - this.transform.position.y;
                var x = this.movementScript.fireTarget.x - this.transform.position.x;
                if (Mathf.Abs(y) > Quaternion.kEpsilon || Mathf.Abs(x) > Quaternion.kEpsilon)
                {
                    this.targetAngle = Mathf.Atan2(y, x) * Mathf.Rad2Deg;
                    //Debug.Log("target angle: " + targetAngle);
                    var angle = this.targetAngle - this.transform.rotation.eulerAngles.z; //this.transform.localRotation.eulerAngles.z;

                    this.transform.RotateAround(this.rotationCenter.position, new Vector3(0, 0, 1), angle);
//          
                }
            }
        }
    
    }
}
