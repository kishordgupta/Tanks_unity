﻿using UnityEngine;
using System.Collections;

public class Stage
{

    public int index;
    public int enemyNumbers;
    public int bossNumbers;

    // Use this for initialization
    void Start()
    {
    
    }
    
    // Update is called once per frame
    void Update()
    {
    
    }
}
