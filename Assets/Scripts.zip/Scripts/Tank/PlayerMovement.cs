﻿using UnityEngine;
using System.Collections;

public class PlayerMovement : Movement
{
 
    public static bool joyStickTouch = false;
    public LayerMask mask;
    public static bool moving;

    void Start()
    {
//        mask =Physics2D.DefaultRaycastLayers & ~LayerMask.GetMask("Floor");
//        print ("layers " + mask +" , "+  LayerMask.GetMask("Floor")+" , "+ ~LayerMask.GetMask("Floor") );
    }


    // Player Fire code
   
    void fire(Vector3 mytouch)
    {
        Ray ray = Camera.main.ScreenPointToRay(mytouch);
        RaycastHit2D hit = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity, mask);
        if (hit != null)
        {
            if (hit.collider != null)
            { 
                base.fireTarget = hit.point;
//                print(" 2nd touch layer mask " + hit.transform.gameObject.layer);
            } else
            {
            }
//                print("hudai atkay achi" + hit.point);
            
        } else
        {

        }
//            print("nope not working");
        
    }
    // Update is called once per frame

   
    void Update()
    {

       
//        Instantiate(Resources.Load("Trail"), new Vector2 (this.gameObject.transform.position.x - 0.7f,this.gameObject.transform.position.y), this.gameObject.transform.rotation);
        if (Time.deltaTime <= 0)
        {
            return;
        }
//        CFInput.ControllerActive()
        
        var h = CFInput.GetAxis("Horizontal");
        var v = CFInput.GetAxis("Vertical");

        if (Mathf.Abs(h) > Quaternion.kEpsilon || Mathf.Abs(v) > Quaternion.kEpsilon)
        {
            PlayerMovement.joyStickTouch = true;
            base.baseDirection = new Vector3(h, v, 0).normalized;
            this.transform.position += base.baseDirection * base.speed * Time.deltaTime;
            if (PlayerPrefs.GetInt("Sound") <= 0)
            if (!GetComponent<AudioSource>().isPlaying)
            {
                GetComponent<AudioSource>().Play();
            }
            moving = true;
        } else
        {
//            if (!GetComponent<AudioSource>().isPlaying)
            GetComponent<AudioSource>().Stop();
            joyStickTouch = false;
            moving = false;
        }
//        #if UNITY_ANDROID || UNITY_IPHONE
        if (Input.touchCount > 1)
        {
            //if player moves
            if (PlayerMovement.joyStickTouch)
            {

//                if (Input.GetTouch(0).position.x < Screen.width / 3 && Input.GetTouch(0).position.y < Screen.height / 3)
//                {
//
//                    fire(Input.GetTouch(1).position);
//
//                } else if (Input.GetTouch(1).position.x < Screen.width / 3 && Input.GetTouch(1).position.y < Screen.height / 3)
//                {
//
//                    fire(Input.GetTouch(0).position);
//
//                }
                                                                                     
                if (Input.GetTouch(0).position.x < Screen.width / 2 && Input.GetTouch(0).position.y < Screen.height / 2)
                {
                    
                    fire(Input.GetTouch(1).position);
                    
                } else if (Input.GetTouch(1).position.x < Screen.width / 2 && Input.GetTouch(1).position.y < Screen.height / 2)
                {
                    
                    fire(Input.GetTouch(0).position);
                    
                }

            }
            //if player doesn't move
            else
            {

                fire(Input.GetTouch(0).position);

            }

        } else if (Input.touchCount > 0)
        {



            if (!PlayerMovement.joyStickTouch)
            {

                if (Input.touchCount == 1)
                {
                    fire(Input.GetTouch(0).position);
                }
            }

        }



      
 
       
    }   
}


