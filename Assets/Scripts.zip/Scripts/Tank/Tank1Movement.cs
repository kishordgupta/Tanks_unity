﻿using UnityEngine;
using System.Collections;
using PigeonCoopToolkit.Navmesh2D;
using System.Collections.Generic;
using System.Linq;

public class Tank1Movement : Movement
{
    public Transform targetFlag;
    private Transform lastTargetFlag;
    private GameObject tankHero;
    private bool targeting;//looking for the target
    float timer ;
    private float normalSpeed = 1f;
    private float bossSpeed = 2.5f;
    private List<Vector2> path;
    private Vector3 lastPos ;

    void Awake()
    {
        tankHero = GameObject.FindGameObjectWithTag(Tags.hero);
        if (this.gameObject.tag != Tags.enemyBoss)
            this.gameObject.rigidbody2D.mass = Random.Range(70, 140);

        targeting = true;
    }

    void Start()
    {
//        nav = GetComponent <NavMeshAgent> ();
        //        iTween.MoveTo(this.gameObject,iTween.Hash("path",iTweenPath.GetPath("enemyPath"),"time",35f,"easetype",iTween.EaseType.linear));
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        //Debug.Log (other.tag);
        if (other.tag == Tags.edge)
        {
            this.targeting = true;
            print("triggering");
        }
    }
//
    void OnCollisionStay2D(Collision2D coll)
    {

        if(coll.gameObject.tag == Tags.wall )
        {

//            print("staying will wall");

        }

    }
        
    // Update is called once per frame
    void FixedUpdate()
    {

        if (tankHero == null)
        {
            return;
        }
        if (Time.deltaTime == 0f)
        {
            return;
        }

        var targetPoint = this.tankHero.transform.position;
        targetPoint.z = this.transform.position.z;

        if (this.targeting)
        {
            var direction = (targetPoint - this.transform.position).normalized;
            base.movingTarget = targetPoint + direction * 0.25f;
            if (this.targetFlag != null)
            {
                if (this.lastTargetFlag != null)
                {
                    Destroy(this.lastTargetFlag.gameObject);
                }
                lastTargetFlag = Instantiate(targetFlag, base.movingTarget, this.transform.rotation) as Transform;
                path = NavMesh2D.GetSmoothedPath(this.transform.position, lastTargetFlag.position);

            }
            this.targeting = false;
        }

        if (path != null && path.Count != 0)
        {
            if (this.gameObject.tag == Tags.enemy)
                this.transform.position = Vector2.MoveTowards(this.transform.position, path.ElementAt(0), normalSpeed * Time.deltaTime);
            else   if (this.gameObject.tag == Tags.enemyBoss)
                this.transform.position = Vector2.MoveTowards(this.transform.position, path.ElementAt(0), bossSpeed * Time.deltaTime);
            if (Vector2.Distance(transform.position, path.ElementAt(0)) < 0.01f)
            {
                path.RemoveAt(0);
            }
        }

        base.fireTarget = targetPoint;
        base.baseDirection = (base.movingTarget - this.transform.position).normalized;

      

        if (this.gameObject.tag == Tags.enemyBoss)
        {
            if ((this.transform.position - base.movingTarget).magnitude < 3f)// || this.rigidbody2D.velocity.magnitude<0f)
            {
                this.targeting = true;
            }
        } else
        {
            if ((this.transform.position - base.movingTarget).magnitude < 2f)// || this.rigidbody2D.velocity.magnitude<0f)
            {
                this.targeting = true;
            }
        }

    }

    void OnDestroy()
    {
        if (this.lastTargetFlag != null)
        {
            Destroy(this.lastTargetFlag.gameObject);
        }
    }
}

