﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

sealed class CannonHeroWeapon : Weapon
{
    public Transform bulletPrefab;
    public Transform bulletStartPosition;
    
    new void Awake()
    {
        base.Awake();
    }
    
    new void Update()
    {
        if (Time.deltaTime == 0)
        {
            return;
        }
        passedInterval += Time.deltaTime * 10;

        #if UNITY_ANDROID || UNITY_IPHONE
        if (passedInterval >= base.shootInterval)
        {
            
            if (Input.touchCount > 1)
            {
                //                if ((Input.GetTouch(1).position.x > 0 && PlayerMovement.joyStickTouch))
                //                if ((Input.GetTouch(1).position.x > 0))
                {
//                    print("bullet touch one ");
                    if (Input.GetTouch(1).phase == TouchPhase.Stationary ||Input.GetTouch(1).phase == TouchPhase.Moved)
                        //                    if (Input.GetTouch(1).position.x > 0 && Input.GetTouch(1).position.y > 0)
                    {
                        passedInterval = 0;
                        var newBullet = Instantiate(bulletPrefab, bulletStartPosition.position, this.transform.rotation) as Transform;
                        var bulletFly = newBullet.GetComponent<BulletFly>();
                        
                        bulletFly.Initiate(base.bulletVelocity, base.shooterTag, base.movementScript.fireTarget);
                        if (PlayerPrefs.GetInt("Sound") <= 0)
                        GetComponent<AudioSource>().Play();
//                        if (PlayerPrefs.GetInt("Sound") <= 0)
//                       
//                        this.shootAudioSource.Play();
                    }
                }
                
                
                //            } else  if (Input.touchCount > 0 && !PlayerMovement.joyStickTouch)
            } else  if (Input.touchCount > 0 && !PlayerMovement.joyStickTouch)
            {
//                    print("bullet touch in zero ");
                
                if (Input.GetTouch(0).phase == TouchPhase.Stationary ||Input.GetTouch(0).phase == TouchPhase.Moved)
                    //                if (Input.GetTouch(0).position.x > 0 && Input.GetTouch(0).position.y > 0)
                {
                    passedInterval = 0;
                    var newBullet = Instantiate(bulletPrefab, bulletStartPosition.position, this.transform.rotation) as Transform;
                    var bulletFly = newBullet.GetComponent<BulletFly>();
                    
                    bulletFly.Initiate(base.bulletVelocity, base.shooterTag, base.movementScript.fireTarget);
                    if (PlayerPrefs.GetInt("Sound") <= 0)
                    GetComponent<AudioSource>().Play();
//                    if (PlayerPrefs.GetInt("Sound") <= 0)
//                    this.shootAudioSource.Play();
                    
                    
                    
                    
                }
            }
        }
        
        #endif

        
        
        
        
        
        
    }
}
