using UnityEngine;
using System.Collections;

public class TakeDamage : MonoBehaviour
{

    private Health healthScript;

    void Awake()
    {
        this.healthScript = this.GetComponentInChildren<Health>();
    }

    void Start()
    {
    }
    void Update()
    {
        
        if (this.healthScript.HP >= 50)
        {
            this.transform.FindChild("HalfLifeEffect").gameObject.SetActive(false);
            //            SpecialEffectsHelper.Instance.HalfLifeParticle(this.transform.position);
        }
    }
    void OnTriggerEnter2D(Collider2D other)
    {

//        print(other.transform.position);
        if (this.healthScript.HP <= 50)
        {
            this.transform.FindChild("HalfLifeEffect").gameObject.SetActive(true);
//            SpecialEffectsHelper.Instance.HalfLifeParticle(this.transform.position);
        }
        Instantiate(Resources.Load("DamageAnimation") as GameObject,other.transform.position, other.transform.rotation) ;
        if (this.healthScript.HP <= 0)
        {
//            Instantiate(Resources.Load("FinalExplosion") as GameObject,this.transform.position, this.transform.rotation) ;
            return;
        }

        var bulletFlyScript = other.GetComponent<BulletFly>();
        if (bulletFlyScript == null)
        {
            return;
        }
        if (bulletFlyScript.shooterTag == this.tag)
        {
            return;
        }
//        SpecialEffectsHelper.Instance.FullExplosionParticle(this.transform.position);
        var damage = bulletFlyScript.GetDamage(this.transform);
        this.healthScript.TakeDamage(damage);
    }
}
