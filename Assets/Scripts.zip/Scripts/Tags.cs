﻿using UnityEngine;
using System.Collections;

public class Tags
{
	public const string hero = "Hero";
    public const string wall = "Wall";
	public const string undying = "Undying";
	public const string edge = "Edge";
    public const string bullet = "Bullet";
    public const string heroBullet ="HeroBullet";
    public const string enemy = "Enemy";
    public const string enemyBoss = "EnemyBoss";
    public const string coin = "Coin";
    public const string levelController = "LevelController";
    public const string carController = "CarController";
}
