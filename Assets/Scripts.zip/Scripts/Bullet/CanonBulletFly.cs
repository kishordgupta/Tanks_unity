﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

class CanonBulletFly : BulletFly
{
    public float damage;
    private float minX, maxX, minY, maxY;
    public static bool play;
    public static bool setting;
    public static bool highScore;
    public AudioClip shellAudioClip;
    protected AudioSource shellAudioSource;

    void Start()
    {
        play = false;
        shellAudioSource = audio;
        shellAudioSource.clip = shellAudioClip;
        //Debug.Log("CanonBulletFly.Start()");
        float camDistance = Vector3.Distance(transform.position, Camera.main.transform.position);
        Vector2 bottomCorner = Camera.main.ViewportToWorldPoint(new Vector3(0, 0, camDistance));
        Vector2 topCorner = Camera.main.ViewportToWorldPoint(new Vector3(1, 1, camDistance));
        minX = bottomCorner.x;
        maxX = topCorner.x;
        minY = bottomCorner.y;
        maxY = topCorner.y;
    }

    void OnTriggerEnter2D(Collider2D collider)
    {
        if (collider.tag == Tags.coin)
            return;

        if (collider.tag == Tags.carController)
        {
            collider.gameObject.GetComponent<CarDead>().CarDestroy();
//            return;
        }
        if (Application.loadedLevel == 0)
        {
            Instantiate(Resources.Load("FinalExplosion") as GameObject, this.transform.position, this.transform.rotation);
            if (collider.tag == "Play")
            {
//                LoadLevel();
                play = true;
                Debug.Log("Play");
            }
            if (collider.tag == "Settings")
            {
                setting = true;
                Debug.Log("setting " + collider.tag);
            }

            if (collider.tag == "HighScore")
            {
                highScore = true;
            }

//            else Debug.Log(" " + collider.tag);
        }
        Instantiate(Resources.Load("DamageAnimation") as GameObject, this.transform.position, this.transform.rotation);
        if (PlayerPrefs.GetInt("Sound") <= 0)
        {
            GetComponent<AudioSource>().Play();
        } 
        else
            GetComponent<AudioSource>().Stop();

        Destroy(this.gameObject);
    }
   
    void LoadLevel()
    {
//        Application.LoadLevel(SceneNames.store);
    }

    public override float GetDamage(Transform gameObject)
    {
        return this.damage;
    }

    public override void Initiate(float velocity, string shooterTag, Vector3 targetPosition)
    {

        base.velocity = velocity;
        base.shooterTag = shooterTag;

        base.targetPosition = targetPosition;
    }
}
