﻿using UnityEngine;
using System.Collections;

public class CoinInfo : MonoBehaviour {

    public int value;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
