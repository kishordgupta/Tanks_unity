﻿using UnityEngine;
using System.Collections;

public class PickedCoin : MonoBehaviour
{

    public AudioClip pickedAudioClip;
    static int point ;
    int pointValue = 5;
    // Use this for initialization
    void Start()
    {
    
    }

    void OnEnable()
    {
       
//        GameEventManager.GamePointCalculation += GamePoint;
    }
    // Update is called once per frame
    void Update()
    {
    
    }

    void OnDisble()
    {
//        GameEventManager.GamePointCalculation -= GamePoint;
    }

  public static   void GamePoint( int p )
    {
//        print("coin picked");
        point = PlayerPrefs.GetInt("Point");
        point += p;
        PlayerPrefs.SetInt("Point", point);
        PlayerPrefs.Save();
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag != Tags.hero)
        {
            return;
        }

//        print("coin picked ontrigger");
//        GameEventManager.TriggerGamePointCalculation();
        GamePoint(pointValue);
        AudioSource.PlayClipAtPoint(pickedAudioClip, this.transform.position, 0.2f);
        

        Destroy(this.gameObject);

    }
}
