﻿using UnityEngine;
using System.Collections;

public class SceneNames
{
	public const string DetonatorTestWall = "Detonator-TestWall";
    public const string GameStart = "GameStart";
    public const string LevelSelect = "LevelSelect";
    public const string Level1 = "FreeLevel1";
    public const string Level2 = "FreeLevel2";
    public const string Level3 = "FreeLevel3";
    public const string Level4 = "FreeLevel4";
    public const string Level5 = "FreeLevel5";
    public const string Level6 = "FreeLevel6";
}
