﻿
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System;
using System.Linq;

class LevelController2 : MonoBehaviour
{
    static int levelIndex = 0;
    public List<Transform> enemyBornPoints;
    public List<Transform> tankPrefabs;
    public int sendSpeed = 100;
    public float sendInterval = 1;
    private float passedInterval;
    private Level currentLevel;
    private List<Transform> aliveTanks;
    private int nextTankIndex;
    DateTime oldDate;
    DateTime currentDate;
    int minutes;
    int seconds;
    int wave;
    bool isStart;
    int enemyArrival = 120;
    public bool highScoreUpdate=true;
    public static bool adShow;
    void Awake()
    {
        int levelIndex = PlayerPrefs.GetInt("Level");
        levelIndex -= 1;
        this.currentLevel = LevelLoader.GetLevel(levelIndex);
//        this.currentLevel = LevelLoader.GetLevel(6);
        levelIndex = 1;

        this.nextTankIndex = 0;

        this.aliveTanks = new List<Transform>();


        foreach (var item in this.currentLevel)
        {
            if (!item.IsStop())
            {
                this.total++;
            }
        }

    }

    // Use this for initialization
    void Start()
    {
        adShow = true;
        highScoreUpdate=true;
        minutes = 0;
        seconds = 0;
        oldDate = System.DateTime.Now;
        wave = 0;
        PlayerPrefs.SetInt("Point", 0);
        PlayerPrefs.Save();
        Time.timeScale = 1f;
        isStart = true;
        iTween.ShakePosition(GameObject.Find("Main Camera"), new Vector3(3f, 3f), 1f);
        InvokeRepeating("generateTanks", 1, 1);
        
    }

    void GameEnded()
    {

        CancelInvoke("generateTanks");
       // HighScoreManager._instance.SaveHighScore("you", PlayerPrefs.GetInt("Point"));
        if (PlayerPrefs.GetInt("HighScore") < PlayerPrefs.GetInt("Point"))
            PlayerPrefs.SetInt("HighScore", PlayerPrefs.GetInt("Point"));

        switch(Application.loadedLevelName)
        {
            case SceneNames.Level1:
                PlayerPrefs.SetInt("LevelUnlock",2);
                break;
            case SceneNames.Level2:
                PlayerPrefs.SetInt("LevelUnlock",3);
                break;
            case SceneNames.Level3:
                PlayerPrefs.SetInt("LevelUnlock",4);
                break;
            case SceneNames.Level4:
                PlayerPrefs.SetInt("LevelUnlock",5);
                break;
            case SceneNames.Level5:
                PlayerPrefs.SetInt("LevelUnlock",6);
                break;
        }

        PlayerPrefs.Save();


        GameObject.Find("TankHero").GetComponent<HeroDamage>().ScoreShow(true);

    }
    // Update is called once per frame
    void Update()
    {



        currentDate = System.DateTime.Now;
        seconds = currentDate.Second - oldDate.Second;


        if (this.aliveTanks.Count == 0 && nextTankIndex >= this.currentLevel.Count)// goto menu for next level
        {
            if(highScoreUpdate)
            {
            GameEnded();
                highScoreUpdate=false;
            }
            adShow = false;
            return;
        }


    }

    void generateTanks()
    {
        currentDate = System.DateTime.Now;
        seconds = currentDate.Second - oldDate.Second;

       
        //
        if (this.aliveTanks.Count > 0)
        {
            
            if (nextTankIndex < this.currentLevel.Count 
                && this.currentLevel [nextTankIndex].IsStop())
            {
                
                
                if (seconds % enemyArrival != 0)
                {
                    return;
                }
                
            }
        }
        isStart = false;
       
        if (nextTankIndex < this.currentLevel.Count)
        {
            passedInterval += Time.deltaTime;
            //            if (passedInterval >= sendInterval)
            {
                //                if (UnityEngine.Random.Range(0, 100) < sendSpeed)
                {
//                    print("isStop" + this.currentLevel [nextTankIndex].IsStop());
                    
                    while (nextTankIndex < this.currentLevel.Count
                           && this.currentLevel[nextTankIndex].IsStop())
                    {
                        nextTankIndex++;
                    }
                    
                    if (nextTankIndex < this.currentLevel.Count)
                    {
                        var egg = this.currentLevel [nextTankIndex];
                        var bornTransform = this.enemyBornPoints.ElementAt(egg.bornPointIndex); //[egg.bornPointIndex];
                        var tank = Instantiate(tankPrefabs.ElementAt(egg.enemyPrefabIndex), bornTransform.position, bornTransform.rotation) as Transform;
                        
                        this.aliveTanks.Add(tank);
                        passedInterval = 0;
                        nextTankIndex++;
                    }
                }
            }
            
        }



    }

    public void EnemyDying(GameObject enemy)
    {
        this.killed++;
        this.aliveTanks.Remove(enemy.transform);
    }

    private int killed = 0;
    private int total = 0;

    public override string ToString()
    {
        var builder = new StringBuilder();
        builder.Append(string.Format("Killed: {0}/{1} next:{2} alive:{3}", killed, total, nextTankIndex, this.aliveTanks.Count));
//        return builder.ToString();
        return "";
    }

}
