﻿using UnityEngine;

public class SpecialEffectsHelper : MonoBehaviour
{
    public static SpecialEffectsHelper Instance;
    
    public ParticleSystem smokeEffect;

    public ParticleSystem explosionEffect;

//    public ParticleSystem halfLifeEffect;

    
    void Awake()
    {

        if (Instance != null)
        {
//            Debug.LogError("Multiple instances of SpecialEffectsHelper!");
        }
        
        Instance = this;
    }

    public void BulletHitParticle(Vector3 position)
    {

        instantiate(smokeEffect, position);
     
    }
    public void FullExplosionParticle(Vector3 position)
    {
        instantiate(explosionEffect,position);
    }
    public void HalfLifeParticle(Vector3 position)
    {
//        instantiate(halfLifeEffect,position);

    }
    private ParticleSystem instantiate(ParticleSystem prefab, Vector3 position)
    {
        ParticleSystem newParticleSystem = Instantiate(
            prefab,
            position,
            Quaternion.identity
            ) as ParticleSystem;
        

        Destroy(
            newParticleSystem.gameObject,
            newParticleSystem.startLifetime
            );
        
        return newParticleSystem;
    }
}