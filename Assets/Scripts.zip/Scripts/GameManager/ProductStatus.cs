﻿using UnityEngine;
using System.Collections;

public class ProductStatus : MonoBehaviour {

    public int maxTank;
    public int tankCount;// { get;set; }
    private Transform factory;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
