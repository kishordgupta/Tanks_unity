﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public class btnstartGameStart : MonoBehaviour
{

    public AudioClip clickSound;
    static   public GameObject settingPanel, highScorePanel;
    static  public GameObject backGround;
    public Button menu, sound, music, highScoreMenu;
    public float originalTimeScale;

    void Awake()
    {
        Time.timeScale = 1f;
    }
    // Use this for initialization
    void Start()
    {


//        ShakePosition(GameObject target, Vector3 amount, float time)


//        iTween.ShakePosition(GameObject.Find("Main Camera"), new Vector3(3f, 3f), 1f);
        settingPanel = GameObject.Find("SPanel");
        highScorePanel = GameObject.Find("HPanel");
        backGround = GameObject.Find("Background");
        originalTimeScale = Time.timeScale;

      


        menu.onClick.AddListener(() => {
            settingPanel.GetComponent<CanvasGroup>().alpha = 0;
            settingPanel.GetComponent<CanvasGroup>().blocksRaycasts = false;
            settingPanel.GetComponent<CanvasGroup>().interactable = false;


            
//            backGround.GetComponent<CanvasGroup>().alpha = 1;
//            backGround.GetComponent<CanvasGroup>().blocksRaycasts = true;
//            backGround.GetComponent<CanvasGroup>().interactable = true;

            CanonBulletFly.setting = false;
            Time.timeScale = originalTimeScale;

        });
        highScoreMenu.onClick.AddListener(() => {
            highScorePanel.GetComponent<CanvasGroup>().alpha = 0;
            highScorePanel.GetComponent<CanvasGroup>().blocksRaycasts = false;
            highScorePanel.GetComponent<CanvasGroup>().interactable = false;
            
            
            
            backGround.GetComponent<CanvasGroup>().alpha = 1;
            backGround.GetComponent<CanvasGroup>().blocksRaycasts = true;
            backGround.GetComponent<CanvasGroup>().interactable = true;
            
            CanonBulletFly.highScore = false;
            Time.timeScale = originalTimeScale;
            
        });


        if (PlayerPrefs.GetInt("Sound") <= 0)
        {
            sound.GetComponent<CanvasGroup>().alpha = 1f;
        } else
        {
            sound.GetComponent<CanvasGroup>().alpha = 0.2f;

        }

        sound.onClick.AddListener(() => {
            if (PlayerPrefs.GetInt("Sound") <= 0)
            {
                PlayerPrefs.SetInt("Sound", 1);
                
                PlayerPrefs.Save();
                sound.GetComponent<CanvasGroup>().alpha = 0.2f;
            } else
            {
                PlayerPrefs.SetInt("Sound", 0);
                
                PlayerPrefs.Save();
                sound.GetComponent<CanvasGroup>().alpha = 1f;
            }
        });


        if (PlayerPrefs.GetInt("Music") <= 0)
        {
            music.GetComponent<CanvasGroup>().alpha = 1f;
            GameObject.Find("Main Camera").GetComponent<AudioSource>().Play();
        } else
        {
            music.GetComponent<CanvasGroup>().alpha = 0.2f;
            GameObject.Find("Main Camera").GetComponent<AudioSource>().Pause();
        }
        music.onClick.AddListener(() => {
            if (PlayerPrefs.GetInt("Music") <= 0)
            {
                PlayerPrefs.SetInt("Music", 1);
                
                PlayerPrefs.Save();
                GameObject.Find("Main Camera").GetComponent<AudioSource>().Pause();
                music.GetComponent<CanvasGroup>().alpha = 0.2f;
            } else
            {
                PlayerPrefs.SetInt("Music", 0);
                
                PlayerPrefs.Save();
                GameObject.Find("Main Camera").GetComponent<AudioSource>().Play();
                music.GetComponent<CanvasGroup>().alpha = 1f;
            }
        });


    }

    public static void LoadHighScore()
    {
        highScorePanel.GetComponent<CanvasGroup>().alpha = 1;
        highScorePanel.GetComponent<CanvasGroup>().blocksRaycasts = true;
        highScorePanel.GetComponent<CanvasGroup>().interactable = true;

       HighScoreShow();
    }

    static void HighScoreShow()
    {
        List<Scores> HighScores = HighScoreManager._instance.GetHighScore();
      //  print(HighScores.ElementAt(0).score.ToString());

       
        print(HighScores.Count);

        for (int i =1; i<=10; i++)
        {
//            print("HighScore Instance " + HighScores [i].name + " score " + HighScores [i].score);
//            print(GameObject.Find("Score"+i+"/score").GetComponent<Text>().text+" hocche na " + GameObject.Find("Score"+i+"/username").GetComponent<Text>().text);
            GameObject.Find("Score" + i + "/username").GetComponent<Text>().text = HighScores.ElementAt(i-1).name.ToString();
            GameObject.Find("Score" + i + "/score").GetComponent<Text>().text = HighScores.ElementAt(i-1).score.ToString();

          

        }
    }

    public static void LoadSetting()
    {
    
//        backGround.GetComponent<CanvasGroup>().alpha = 0.5f;
//        backGround.GetComponent<CanvasGroup>().blocksRaycasts = false;
//        backGround.GetComponent<CanvasGroup>().interactable = false;
//

        settingPanel.GetComponent<CanvasGroup>().alpha = 1;
        settingPanel.GetComponent<CanvasGroup>().blocksRaycasts = true;
        settingPanel.GetComponent<CanvasGroup>().interactable = true;


     
    
    }
    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape)) 
            Application.Quit(); 
        //        if (CanonBulletFly.setting == true)
//        {
//           
//        }
    }

    public void btnStart_Click()
    {
        if (clickSound != null)
        {
            AudioSource.PlayClipAtPoint(clickSound, Camera.main.transform.position);
        }
        Application.LoadLevel(SceneNames.LevelSelect);
    }
}
