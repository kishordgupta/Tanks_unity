using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class btnPause : MonoBehaviour
{

    public static float originalTimeScale;
    private Button button;
    public Button sound, music, resume, menu;
    public GameObject panel;
    public Sprite playSprite;
    public Sprite pauseSprite;
    public GameObject[] scoreImage;
    public Sprite[] numbers;
//    public Image score;
    Image image, image1, image2;

    void Awake()
    {
        originalTimeScale = Time.timeScale;
        button = GetComponent<Button>();
//        this.buttonText = this.GetComponentInChildren<UnityEngine.UI.Text>();
    }

    void OnGUI()
    {

    }
    // Use this for initialization
    void Start()
    {

        image = scoreImage [0].gameObject.AddComponent<Image>();
        image.sprite = numbers [0];

        image1 = scoreImage [1].gameObject.AddComponent<Image>();
        image1.sprite = numbers [0];

        image2 = scoreImage [2].gameObject.AddComponent<Image>();
        image2.sprite = numbers [0];

        menu.onClick.AddListener(() => {
			Time.timeScale = 1f;//originalTimeScale;
            Application.LoadLevel(SceneNames.LevelSelect);
        });
        resume.onClick.AddListener(() => {
            GameObject.Find("SPanel").GetComponent<CanvasGroup>().alpha = 0;
            GameObject.Find("SPanel").GetComponent<CanvasGroup>().interactable = false;
            GameObject.Find("SPanel").GetComponent<CanvasGroup>().blocksRaycasts = false;

            
            button.GetComponent<CanvasGroup>().alpha = 1;
            button.GetComponent<CanvasGroup>().interactable = true;
            button.GetComponent<CanvasGroup>().blocksRaycasts = true;
			Time.timeScale = 1f;//originalTimeScale;
        });



        if (PlayerPrefs.GetInt("Sound") <= 0)
        {
            sound.GetComponent<CanvasGroup>().alpha = 1f;

        } else
        {
            sound.GetComponent<CanvasGroup>().alpha = 0.2f;

        }
        sound.onClick.AddListener(() => {
            if (PlayerPrefs.GetInt("Sound") <= 0)
            {
                PlayerPrefs.SetInt("Sound", 1);
                
                PlayerPrefs.Save();
              
                sound.GetComponent<CanvasGroup>().alpha = 0.2f;
            } else
            {
                PlayerPrefs.SetInt("Sound", 0);
                
                PlayerPrefs.Save();
               
                sound.GetComponent<CanvasGroup>().alpha = 1f;
            }
        });


        if (PlayerPrefs.GetInt("Music") <= 0)
        {
            music.GetComponent<CanvasGroup>().alpha = 1f;
            GameObject.Find("Main Camera").GetComponent<AudioSource>().Play();
        } else
        {
            music.GetComponent<CanvasGroup>().alpha = 0.2f;
            GameObject.Find("Main Camera").GetComponent<AudioSource>().Pause();
        }
        music.onClick.AddListener(() => {
            if (PlayerPrefs.GetInt("Music") <= 0)
            {
                PlayerPrefs.SetInt("Music", 1);

                PlayerPrefs.Save();
                GameObject.Find("Main Camera").GetComponent<AudioSource>().Pause();
                music.GetComponent<CanvasGroup>().alpha = 0.2f;
            } else
            {
                PlayerPrefs.SetInt("Music", 0);
              
                PlayerPrefs.Save();
                GameObject.Find("Main Camera").GetComponent<AudioSource>().Play();
                music.GetComponent<CanvasGroup>().alpha = 1f;
            }
        });

    }
    
    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            btnPause_Click();
        }

        ScoreShow();


    }

    void ScoreShow()
    {
        int score = PlayerPrefs.GetInt("Point");
        int reverse = 0;
        int index = 0;
        int[] scoreArray = new int[3];
        while (score != 0)
        {

            scoreArray [index] = score % 10;
            score = score / 10;
            index++;
        }

        image.sprite = numbers[ scoreArray [0]];
        image1.sprite = numbers[ scoreArray [1]];
        image2.sprite = numbers[ scoreArray [2]];
    }

    public void btnPause_Click()
    {
        if (Time.timeScale > 0)
        {
            Time.timeScale = 0;

//            button.image.sprite = playSprite;

            GameObject.Find("SPanel").GetComponent<CanvasGroup>().alpha = 1;
            GameObject.Find("SPanel").GetComponent<CanvasGroup>().interactable = true;
            GameObject.Find("SPanel").GetComponent<CanvasGroup>().blocksRaycasts = true;

            button.GetComponent<CanvasGroup>().alpha = 0;
            button.GetComponent<CanvasGroup>().interactable = false;
            button.GetComponent<CanvasGroup>().blocksRaycasts = false;

        } else
        {
			Time.timeScale = 1f;//originalTimeScale;

            button.image.sprite = pauseSprite;
        }
    }
}
