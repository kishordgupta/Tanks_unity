﻿
using System.Collections.Generic;

using UnityEngine;

using System.Collections;
using System.Collections.Generic;
using System.Linq;

class CarController : MonoBehaviour
{
    static int levelIndex = 0;
    public List<Transform> enemyBornPoints;
    public  List<Transform> nodePoints1;
    public  List<Transform> nodePoints2;
    public List<GameObject> carPrefab;
    public int sendSpeed = 100;
    public float sendInterval = 1;
    private float passedInterval;
    private Level currentLevel;
    private List<GameObject> aliveCars;
    private int nextCarIndex;
    public Sprite[] carSprites;
    public GameObject carPrefabb;
    int pos;
    GameObject car;
    private Health healthScript;

    void Awake()
    {
        this.currentLevel = LevelLoader.GetLevel(levelIndex);
        //        print("current level " + this.currentLevel + " levelIndex " + levelIndex );
        levelIndex = 0;
//        this.healthScript = this.GetComponentInChildren<Health>();
        this.nextCarIndex = 0;
        
        this.aliveCars = new List<GameObject>();
        
        if (sendSpeed > 100)
        {
            sendSpeed = 100;
        }
        
        foreach (var item in this.currentLevel)
        {
            if (!item.IsStop())
            {
                this.total++;
            }
        }

//        InvokeRepeating("CarCreate", 2f, 2f);
//        StartCoroutine(CarCreate());
//      Invoke(  "CarCreate",2f);
//      Invoke(  "CarCreate",3f);
//      Invoke(  "CarCreate",4f);
//

      if(Application.loadedLevel != 7)  // Level 6 we dont need any car point there
        CarCreate();
    }
    
    // Use this for initialization
    void Start()
    {

    }

    void CarCreate()
    {

        var bornTransform = this.enemyBornPoints.ElementAt((int)Random.Range(0, 3)); //[(int)Random.Range(0, 3)];

        car = Instantiate(carPrefabb, bornTransform.position, bornTransform.rotation) as GameObject;
//        car.transform.Find("CarBase/BaseSprite").GetComponent<SpriteRenderer>().sprite = carSprites[(int)Random.Range(0,3)];
        this.aliveCars.Add(car);
        nextCarIndex++;

//        yield return new WaitForSeconds(1.5f);
    }
    // Update is called once per frame
    void Update()
    {
 
    }
    
    public void EnemyDying()
    {
        this.killed++;
        this.aliveCars.Remove(car);
        Destroy(car);
        CarCreate();
    }

    public void EnemyKilling()
    {
        this.killed++;
        this.aliveCars.Remove(car);
//        this.healthScript.FillHealth(100);
        Destroy(car);

        CarCreate();

    }

    private int killed = 0;
    private int total = 0;

    
}

