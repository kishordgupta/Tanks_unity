﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public class CarDead : MonoBehaviour
{
//    public Transform explosionPrefab;
    public List<Transform> goods;
    private Health healthScript;
    private CarController carController;
    
    void Awake()
    {
        if (goods == null)
        {
            goods = new List<Transform>();
        }
        healthScript = this.GetComponentInChildren<Health>();

        var carControllerGameObject = GameObject.FindGameObjectWithTag(Tags.carController);
        this.carController = carControllerGameObject.GetComponent<CarController>();
    }
    
    // Use this for initialization
    void Start()
    {
        
    }

    public void CarDestroy()
    {
        var index = Random.Range(0, goods.Count);
        
        Instantiate(Resources.Load("FinalExplosion") as GameObject, new Vector3(this.transform.position.x, this.transform.position.y, 5f), this.transform.rotation);
        Instantiate(goods.ElementAt(index), new Vector3(this.transform.position.x, this.transform.position.y, 5f), this.transform.rotation);
        
        carController.EnemyKilling();
    }

    void OnCollisionEnter2D(Collision2D  other)
    {
        if (other.collider.tag == Tags.hero || other.collider.tag == Tags.heroBullet)
        {
            CarDestroy();
            print("Collision");
        }
//        else
//            print("other Collision");
    }
    // Update is called once per frame
    void Update()
    {
        if (healthScript.HP > 0)
        {
            return;
        }

        if (goods == null || goods.Count < 1)
        {
            return;
        }

    }
}
