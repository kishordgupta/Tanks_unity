﻿using UnityEngine;
using System.Collections;

public class CarDamage : MonoBehaviour {

    private Health healthScript;
    
    void Awake()
    {
        this.healthScript = this.GetComponentInChildren<Health>();
    }
    
    void Start()
    {
    }

    void OnCollisionEnter2D(Collision2D  other)
    {
       
    }
    void OnTriggerEnter2D(Collider2D other)
    {
//        print("Collision");
//        if(other.tag == Tags.hero)
//        {
//          
//            
//        }
        if (this.healthScript.HP <= 0)
        {
            
            print("Game over in take damage");
//            Application.LoadLevel(SceneNames.gameStart);
            return;
        }
        
        var bulletFlyScript = other.GetComponent<BulletFly>();
        if (bulletFlyScript == null)
        {
            return;
        }
        if (bulletFlyScript.shooterTag == this.tag)
        {
            return;
        }
        
        var damage = bulletFlyScript.GetDamage(this.transform);
        this.healthScript.TakeDamage(damage);
    }
}
