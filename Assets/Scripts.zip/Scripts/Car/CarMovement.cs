﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CarMovement: Movement
{

    public Transform targetFlag;
    private Transform lastTargetFlag;
    private GameObject tankHero;
    private bool targeting;//looking for the target
    private CarController carController;
    private float constantSpeed = 6f;
    private float zValueOfCar = 5f;
//    public List<Transform> nodePath;

    void Awake()
    {
        tankHero = GameObject.FindGameObjectWithTag(Tags.hero);
        
        targeting = true;
        var carControllerGameObject = GameObject.FindGameObjectWithTag(Tags.carController);
        carController = carControllerGameObject.GetComponent<CarController>();

    }
    
    void Start()
    {
        if (tankHero == null)
            return;

        switch (PlayerPrefs.GetInt("Level"))
        {
            case 1:
                if (this.gameObject.transform.position.y < 0)
                {
                    iTween.RotateTo(this.gameObject, iTween.Hash("z", 180));
                    this.transform.position = carController.nodePoints1 [0].position;
                    iTween.MoveTo(this.gameObject, iTween.Hash("position", new Vector3(carController.nodePoints1 [1].position.x, carController.nodePoints1 [1].position.y, zValueOfCar), "speed", constantSpeed, "easetype", iTween.EaseType.linear, "oncomplete", "rotateAnd2ndNode1", "oncompletetarget", this.gameObject, "oncompleteparams", 2));
                } else
                {
                    iTween.RotateTo(this.gameObject, iTween.Hash("z", 0));
                    this.transform.position = carController.nodePoints2 [0].position;
                    if ((int)Random.Range(0, 2) < 1)
                        iTween.MoveTo(this.gameObject, iTween.Hash("position", new Vector3(carController.nodePoints2 [1].position.x, carController.nodePoints2 [1].position.y, zValueOfCar), "speed", constantSpeed, "easetype", iTween.EaseType.linear, "oncomplete", "destroyCar", "oncompletetarget", this.gameObject, "oncompleteparams", this.gameObject));
                    else 
                        iTween.MoveTo(this.gameObject, iTween.Hash("position", new Vector3(carController.nodePoints2 [2].position.x, carController.nodePoints2 [2].position.y, zValueOfCar), "speed", constantSpeed, "easetype", iTween.EaseType.linear, "oncomplete", "rotateAnd2ndNode2", "oncompletetarget", this.gameObject, "oncompleteparams", 3));
                }
                break;
            case 2:
                if (this.gameObject.transform.position.y < 0)
                {
                    iTween.RotateTo(this.gameObject, iTween.Hash("z", 180));
                    this.transform.position = carController.nodePoints1 [0].position;
                    iTween.MoveTo(this.gameObject, iTween.Hash("position", new Vector3(carController.nodePoints1 [1].position.x, carController.nodePoints1 [1].position.y, zValueOfCar), "speed", constantSpeed, "easetype", iTween.EaseType.linear, "oncomplete", "rotateAnd2ndNode1", "oncompletetarget", this.gameObject, "oncompleteparams", 2));
                } else
                {

                    this.transform.position = carController.nodePoints2 [0].position;
                    iTween.MoveTo(this.gameObject, iTween.Hash("position", new Vector3(carController.nodePoints2 [1].position.x, carController.nodePoints2 [1].position.y, zValueOfCar), "speed", constantSpeed, "easetype", iTween.EaseType.linear, "oncomplete", "rotateAnd2ndNode2", "oncompletetarget", this.gameObject, "oncompleteparams", 2));
                }
                break;
            case 3:
                if (this.gameObject.transform.position.y < 0)
                {
                    iTween.RotateTo(this.gameObject, iTween.Hash("z", 180));
                    this.transform.position = carController.nodePoints1 [0].position;
                    if ((int)Random.Range(0, 2) < 1)
                    {
                        iTween.MoveTo(this.gameObject, iTween.Hash("position", new Vector3(carController.nodePoints1 [1].position.x, carController.nodePoints1 [1].position.y, zValueOfCar), "speed", constantSpeed, "easetype", iTween.EaseType.linear, "oncomplete", "rotateAnd2ndNode1", "oncompletetarget", this.gameObject, "oncompleteparams", 2));
                    } else
                    {

                        iTween.MoveTo(this.gameObject, iTween.Hash("position", new Vector3(carController.nodePoints1 [4].position.x, carController.nodePoints1 [4].position.y, zValueOfCar), "speed", constantSpeed, "easetype", iTween.EaseType.linear, "oncomplete", "rotateAnd2ndNode1", "oncompletetarget", this.gameObject, "oncompleteparams", 5));
                    }
                } else
                {
                    iTween.RotateTo(this.gameObject, iTween.Hash("z", 0));
                    this.transform.position = carController.nodePoints2 [0].position;
                    iTween.MoveTo(this.gameObject, iTween.Hash("position", new Vector3(carController.nodePoints2 [1].position.x, carController.nodePoints2 [1].position.y, zValueOfCar), "speed", constantSpeed, "easetype", iTween.EaseType.linear, "oncomplete", "destroyCar", "oncompletetarget", this.gameObject, "oncompleteparams", this.gameObject));
                }
                break;
            case 4:
                if (this.gameObject.transform.position.y < 0)
                {
                    iTween.RotateTo(this.gameObject, iTween.Hash("z", -135));
                    this.transform.position = carController.nodePoints1 [0].position;
                    iTween.MoveTo(this.gameObject, iTween.Hash("position", new Vector3(carController.nodePoints1 [1].position.x, carController.nodePoints1 [1].position.y, zValueOfCar), "speed", constantSpeed, "easetype", iTween.EaseType.linear, "oncomplete", "destroyCar", "oncompletetarget", this.gameObject, "oncompleteparams", this.gameObject));
                } else
                {
                    iTween.RotateTo(this.gameObject, iTween.Hash("z", 45));
                    this.transform.position = carController.nodePoints2 [0].position;
                    iTween.MoveTo(this.gameObject, iTween.Hash("position", new Vector3(carController.nodePoints2 [1].position.x, carController.nodePoints2 [1].position.y, zValueOfCar), "speed", constantSpeed, "easetype", iTween.EaseType.linear, "oncomplete", "destroyCar", "oncompletetarget", this.gameObject, "oncompleteparams", this.gameObject));
                }
                break;
            case 5:
                if (this.gameObject.transform.position.y < 0)
                {
                    iTween.RotateTo(this.gameObject, iTween.Hash("z", 180));
                    this.transform.position = carController.nodePoints1 [0].position;
                    if ((int)Random.Range(0, 2) < 1)
                    {

                        iTween.MoveTo(this.gameObject, iTween.Hash("position", new Vector3(carController.nodePoints1 [1].position.x, carController.nodePoints1 [1].position.y, zValueOfCar), "speed", constantSpeed, "easetype", iTween.EaseType.linear, "oncomplete", "rotateAnd2ndNode1", "oncompletetarget", this.gameObject, "oncompleteparams", 2));
                    } else
                    {

                        iTween.MoveTo(this.gameObject, iTween.Hash("position", new Vector3(carController.nodePoints1 [4].position.x, carController.nodePoints1 [4].position.y, zValueOfCar), "speed", constantSpeed, "easetype", iTween.EaseType.linear, "oncomplete", "rotateAnd2ndNode1", "oncompletetarget", this.gameObject, "oncompleteparams", 5));
                    }
                } else
                {
                    iTween.RotateTo(this.gameObject, iTween.Hash("z", -45));
                    this.transform.position = carController.nodePoints2 [0].position;
                    iTween.MoveTo(this.gameObject, iTween.Hash("position", new Vector3(carController.nodePoints2 [1].position.x, carController.nodePoints2 [1].position.y, zValueOfCar), "speed", constantSpeed, "easetype", iTween.EaseType.linear, "oncomplete", "destroyCar", "oncompletetarget", this.gameObject, "oncompleteparams", this.gameObject));
                }
                break;

        }





     
    }
  
    void rotateAnd2ndNode1(int i)
    {
        iTween.RotateTo(this.gameObject, iTween.Hash("z", 270, "speed", constantSpeed * 3));
        iTween.MoveTo(this.gameObject, iTween.Hash("position", new Vector3(carController.nodePoints1 [i].position.x, carController.nodePoints1 [i].position.y, zValueOfCar), "speed", constantSpeed / 3, "easetype", iTween.EaseType.linear, "oncomplete", "moveTo3rdNode1", "oncompletetarget", this.gameObject, "oncompleteparams", i + 1));
    }

    void rotateAnd2ndNode2(int i)
    {
        iTween.RotateTo(this.gameObject, iTween.Hash("z", 90, "speed", constantSpeed * 3));
        iTween.MoveTo(this.gameObject, iTween.Hash("position", new Vector3(carController.nodePoints2 [i].position.x, carController.nodePoints2 [i].position.y, zValueOfCar), "speed", constantSpeed / 3, "easetype", iTween.EaseType.linear, "oncomplete", "moveTo3rdNode2", "oncompletetarget", this.gameObject, "oncompleteparams", i + 1)); 
    }

    void moveTo3rdNode2(int i)
    {
        iTween.MoveTo(this.gameObject, iTween.Hash("position", new Vector3(carController.nodePoints2 [i].position.x, carController.nodePoints2 [i].position.y, zValueOfCar), "speed", constantSpeed, "easetype", iTween.EaseType.linear, "oncomplete", "destroyCar", "oncompletetarget", this.gameObject, "oncompleteparams", this.gameObject)); 
    }

    void moveTo3rdNode1(int i)
    {
        iTween.MoveTo(this.gameObject, iTween.Hash("position", new Vector3(carController.nodePoints1 [i].position.x, carController.nodePoints1 [i].position.y, zValueOfCar), "speed", constantSpeed, "easetype", iTween.EaseType.linear, "oncomplete", "destroyCar", "oncompletetarget", this.gameObject, "oncompleteparams", this.gameObject));
    }


    void destroyCar(GameObject ob)
    {

       
        carController.EnemyDying();

    }
   
    void OnTriggerEnter2D(Collider2D other)
    {
        //Debug.Log (other.tag);

        if (other.tag == Tags.hero)
        {

            
        }
        if (other.tag == Tags.edge)
        {
            this.targeting = true;
        }
    }
    
    
    // Update is called once per frame
    void Update()
    {
       
    }
    
    void OnDestroy()
    {
        if (this.lastTargetFlag != null)
        {
            Destroy(this.lastTargetFlag.gameObject);
        }
    }
}
